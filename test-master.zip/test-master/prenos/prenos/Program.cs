﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prenos
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }

    class Nastavitve
    {

    }

    class Igra
    {
        Dictionary<string, string> poteza = new Dictionary<string, string>();

        public Igra()
        {
            poteza.Add("levo", "1");
        }
    }
}
